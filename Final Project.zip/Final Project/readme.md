report.md          -- write-up of the project
data_h.csv         -- data used to fit mixture model
mixture_model.stan -- stan model
mixture.ipynb      -- python code to fit model and get posteriors